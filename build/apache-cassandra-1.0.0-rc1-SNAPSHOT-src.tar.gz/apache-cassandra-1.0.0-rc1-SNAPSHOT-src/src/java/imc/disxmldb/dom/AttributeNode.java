/**
*@author:xiafan xiafan68@gmail.com
*@version: 2011-10-2 0.1
*/
package imc.disxmldb.dom;

/**
 * the interface for an attribute node
 */
public interface AttributeNode {
	
}

