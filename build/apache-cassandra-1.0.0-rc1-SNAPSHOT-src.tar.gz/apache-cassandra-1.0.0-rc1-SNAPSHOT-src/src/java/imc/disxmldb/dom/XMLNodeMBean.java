package imc.disxmldb.dom;

/**
 * define the interface to provide runtime information to
 * support JMX
 * @author xiafan
 *
 */
public interface XMLNodeMBean {
	public long getSerializeLatency();
	public long getDeserializeLatency();
}
