package imc.disxmldb.dom.schema;

public abstract class SchemaType {
	public static String BASIC_STRING = "string";
	public static String BASIC_INTEGER = "integer";
	public static String BASIC_DOUBLE = "double";
	public static String BASIC_FLOAT = "float";
	public static String BASIC_BOOLEAN = "boolean";
	public static String BASIC_DATE = "date";
	
	private String name = null;
	
	public SchemaType(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
}
