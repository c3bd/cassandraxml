package imc.disxmldb.dom.schema;

public class SchemaElement {
	public String tagName = null;
	public String typeName = null;
	public boolean isAttr = true;
	
	public SchemaElement(String tagName, String typeName, boolean isAttr) {
		this.tagName = tagName;
		this.typeName = typeName;
		this.isAttr = isAttr;
	}

	public String getTagName() {
		return tagName;
	}

	public void setTagName(String tagName) {
		this.tagName = tagName;
	}

	public String getTypeName() {
		return typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}
	
	
}
