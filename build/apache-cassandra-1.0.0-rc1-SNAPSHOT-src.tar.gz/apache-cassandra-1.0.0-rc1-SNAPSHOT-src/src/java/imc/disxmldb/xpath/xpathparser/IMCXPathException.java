package imc.disxmldb.xpath.xpathparser;

public class IMCXPathException extends Exception {
	public IMCXPathException(String message) {
		super(message);
	}
}
