package imc.disxmldb.xpath;

/**
 * define the constant for the XPath
 */
public class XPathConstant {
	public static final String CURSLASH = "/";
	public static final String DESCENDENTSLASH = "//";
	public static final String OPENPARAN = "(";
	public static final String CLOSEPARAN = ")";
	public static final String OPENBRACKET = "[";
	public static final String COMMA = ","; 
	//function name
	public static final String CONTAINS = "contains";
}
