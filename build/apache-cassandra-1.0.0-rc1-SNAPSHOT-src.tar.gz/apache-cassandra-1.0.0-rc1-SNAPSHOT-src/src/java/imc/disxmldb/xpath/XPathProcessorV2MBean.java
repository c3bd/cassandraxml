package imc.disxmldb.xpath;
/**
 * Interface needed by the JMX framework to provide the run state of the
 * monitored object
 */
public interface XPathProcessorV2MBean {
	public double getAvgEEJoinLatency();
	public double getAvgEVJoinLatency();
	public double getAvgXPathExecLatency();
	double getAvgLoadLatency();
}
