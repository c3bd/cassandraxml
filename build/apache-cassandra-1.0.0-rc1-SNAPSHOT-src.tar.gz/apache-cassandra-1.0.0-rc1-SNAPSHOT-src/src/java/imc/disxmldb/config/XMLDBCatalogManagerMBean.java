package imc.disxmldb.config;

public interface XMLDBCatalogManagerMBean {
	public void repairCollectionMetadata(int colID);
}
