package imc.disxmldb.xupdate;
/**
 * Interface needed by the JMX framework to provide the run state of the
 * monitored object
 */
public interface AppendHandlerMBean {

}
