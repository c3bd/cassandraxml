package imc.disxmldb.util;

public interface XMLNodeSerializerMBean {
	public long getSerializeLatency();
	public long getDeserializeLatency();
}
