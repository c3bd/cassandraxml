package imc.disxmldb.util;

import java.nio.ByteBuffer;

public interface IDigestAble {
	public ByteBuffer getDigest();
}
