/**
*@author:xiafan xiafan68@gmail.com
*@version: 2011-10-19 0.1
*/
package imc.jettyserver;

public interface XMLDBServerBean {
	public int getServerThreads();
}
